#!/bin/bash

NC='\033[0;37m' 
PURPLE='\033[0;34m' 
GREEN='\033[0;32m' 
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }

# // Export Align
export BOLD="\e[1m"
export WARNING="${red}\e[5m"
export UNDERLINE="\e[4m"

clear
cekray=`cat /root/log-install.txt | grep -ow "XRAY" | sort | uniq`
if [ "$cekray" = "XRAY" ]; then
domen=`cat /etc/xray/domain`
else
domen=`cat /etc/v2ray/domain`
fi
opensh=`cat /root/log-install.txt | grep -w "OpenSSH" | cut -f2 -d: | awk '{print $1}'`
db=`cat /root/log-install.txt | grep -w "Dropbear" | cut -f2 -d: | awk '{print $1,$2}'`

user="${1:-Trial}"
Pass="${2:-belisayang}"
iplimit="${3:-1}"
masaaktif="${4:-1}"
pup="30"
Login="${user}ssh$(tr -dc 0-9 </dev/urandom | head -c3)"

clear
useradd -e `date -d "$masaaktif days" +"%Y-%m-%d"` -s /bin/false -M $Login
exp="$(chage -l $Login | grep "Account expires" | awk -F": " '{print $2}')"
echo -e "$Pass\n$Pass\n"|passwd $Login &> /dev/null
PID=`ps -ef |grep -v grep | grep sshws |awk '{print $2}'`
clear

echo userdel -f "$Login" | at now + $pup minutes
echo "tunnel ssh ${Login}" | at now +$pup minutes &> /dev/null

mkdir -p /detail/ssh/
#Simpan Detail Akun User
cat > /detail/ssh/$Login.txt <<-END
-----------------------------------------
BY ARYA NBC
wa.me/6281450330727
-----------------------------------------
Trial SSH Account
-----------------------------------------
Host             : $domen
IP               : $IP
Username         : $Login
Password         : $Pass
-----------------------------------------
Limit Ip         : 2 IP
Port OpenSSH     : 22
Port Dropbear    : 143, 109
Port SSH WS      : 80, 8080, 8880, 2082, 2086, 2052, 2095
Port SSH WS SSL  : 443, 8443, 2087, 2096, 2053, 2083
Port SSL/TLS     : 443
BadVPN UDP       : 7100, 7300, 7300
-----------------------------------------
HTTP CUSTOM      : $domen:80@$Login:$Pass"
-----------------------------------------
Payload          : GET / HTTP/1.1[crlf]Host: [host_port][crlf]Upgrade: Websocket[crlf]Connection: Keep-Alive[crlf][crlf]
-----------------------------------------
Dibuat Pada      : $hariini
Aktif Selama     : $pup menit
-----------------------------------------

END

cat > /var/www/html/ssh-$Login.txt <<-END
-----------------------------------------
Trial SSH Account
-----------------------------------------
Host             : $domen
IP               : $IP
Username         : $Login
Password         : $Pass
-----------------------------------------
Limit Ip         : 2 IP
Port OpenSSH     : 22
Port Dropbear    : 143, 109
Port SSH WS      : 80, 8080, 8880, 2082, 2086, 2052, 2095
Port SSH WS SSL  : 443, 8443, 2087, 2096, 2053, 2083
Port SSL/TLS     : 443
BadVPN UDP       : 7100, 7300, 7300
-----------------------------------------
HTTP CUSTOM      : $domen:80@$Login:$Pass"
-----------------------------------------
Payload          : GET / HTTP/1.1[crlf]Host: [host_port][crlf]Upgrade: Websocket[crlf]Connection: Keep-Alive[crlf][crlf]
-----------------------------------------
Dibuat Pada      : $hariini
Aktif Selama     : $pup menit
-----------------------------------------

END
CHATID="6430177985"
KEY="7567594287:AAGVeDwRq9QrNg6jSce30eOm9WiVtAWKxjA"
export TIME="10"
export URL="https://api.telegram.org/bot$KEY/sendMessage"
sensor=$(echo "$Login" | sed 's/\(.\{3\}\).*/\1xxx/')
ISP=$(curl -s ipinfo.io/org | cut -d " " -f 2-10 )
clear
export TIME="10"
TEXT="
<b>-----------------------------------------</b>
<b>TRANSACTION SUCCESSFUL</b>
<b>-----------------------------------------</b>
<b>» Produk : Trial SSH</b>
<b>» ISP :</b> <code>${ISP}</code>
<b>» Limit Quota :</b> <code>${Quota} GB</code>
<b>» Limit Login :</b> <code>${iplimit} Hp</code>
<b>» Username :</b> <code>${sensor}</code>
<b>» Duration :</b> <code>${pup} Minutes</code>
<b>-----------------------------------------</b>
<i>Automatic Notification From Server</i>
<b>-----------------------------------------</b>
"

clear
echo -e "${PURPLE}═════════════\033[0;33mSSH ACCOUNTS\033[0;34m═══════════${NC}"
echo -e "${PURPLE}════════════════════════════════════${NC}"
echo -e "Username   : $Login" 
echo -e "Password   : $Pass"
echo -e "Expired On : $pup menit" 
echo -e "${PURPLE}════════════════════════════════════${NC}"
echo -e "Host       : $domen" 
echo -e "OpenSSH    : $opensh"
echo -e "Dropbear   : $db" 
echo -e "SSH-WS     : 80, 8080, 8880, 2082, 2086, 2052, 2095" 
echo -e "SSH WS SSL : 443, 8443, 2087, 2096, 2053, 2083 " 
echo -e "SSL/TLS    : 444, 445, 447, 777" 
echo -e "SSH HTTP   : $domen:80@$Login:$Pass"
echo -e "UDPGW      : 7100-7300" 
echo -e "${PURPLE}════════════════════════════════════${NC}"
echo -e " "
echo -e "PAYLOD WS-ORI : GET / HTTP/1.1[crlf]Host: [host_port][crlf]Upgrade: Websocket[crlf]Connection: Keep-Alive[crlf][crlf]"
echo -e ""
echo -e "PAYLOD WS : GET /cdn-cgi/trace HTTP/1.1[crlf]Host: bug.com[crlf]Connection: Keep-Alive[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf][crlf]"
echo -e ""
echo -e "PAYLOD HANDED : GET / HTTP/1.1[crlf]Host: bug.com[crlf][crlf]PATCH / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf][crlf][split]HTTP/ 1[crlf][crlf]"
echo -e ""
echo -e "PAYLOD WS/TLS : GET wss://[host_port]/ HTTP/1.1[crlf]Host: [host_port][crlf]Upgrade: Websocket[crlf]Connection: Keep-Alive[crlf][crlf]"
echo -e " "
echo -e "\033[0;34m══════════════════════════════════${NC}"
echo -e "\033[0;32m Sc By Arya Blitar ${NC}" 
echo ""
read -n 1 -s -r -p "   Press any key to back on menu"
menu-ssh
